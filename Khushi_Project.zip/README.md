# Chandigarh University — Financial Analysis and Presentation

**Student:** Khushi  
**UID:** 26BCD10392  
**Department:** UIC  
**Programme / Semester:** BCD — 1st Semester  
**Submitted to:** Mr. Simranjeet  

## Project files
- `ABC_Corporation_Financial_Analysis.xlsx` — sample statements, formulas, ratios, trend analysis, and chart.
- `ABC_Corporation_Project_Report.docx` — written report with university and student details.
- `ABC_Corporation_Project_Presentation.pptx` — presentation with Chandigarh University logo and student details.

## Data note
All financial figures are fictional illustrative sample data for 2023–2025; they are not actual ABC Corporation results.

## Before submitting
1. Review all files and confirm they meet your instructor's requirements.
2. Upload these files and this README to a new **public** GitHub repository.
3. Paste the repository URL into the Google Form and upload the report, Excel file, and presentation as required.

Suggested repository name: `financial-analysis-presentation`
